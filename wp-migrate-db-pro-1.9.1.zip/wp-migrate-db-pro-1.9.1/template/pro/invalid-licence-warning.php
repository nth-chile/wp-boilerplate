<div class="notification-message warning-notice inline-message invalid-licence">
	<?php echo $this->license->get_licence_status_message(); ?>
</div>
