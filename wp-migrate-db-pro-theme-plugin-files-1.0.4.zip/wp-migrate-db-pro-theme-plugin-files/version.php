<?php
$GLOBALS['wpmdb_meta']['wp-migrate-db-pro-theme-plugin-files']['version'] = '1.0.4';
